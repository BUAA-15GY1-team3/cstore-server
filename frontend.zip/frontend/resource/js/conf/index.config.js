$(function () {
	seajs.use('xpanIndexStyle');
	seajs.use('xpanIndex');
});