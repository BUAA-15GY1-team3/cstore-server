### 前端解析

#### 文件夹解析
![图片](http://bos.nj.bpc.baidu.com/v1/agroup/8b18d8e508dd8d316b9583f264457cc69bf8045a)
```
frontend:前端文件
resource：存储静态文件：css,images,js
js/conf : 配置文件
js/media: 公共js文件，如jquery，sea，bootstrap等
js/pan  ：编写文件，每个页面对应多个js文件
login.html:登录页
regist.html : 注册页
index.html: 首页
```

### 登录页
![图片](http://bos.nj.bpc.baidu.com/v1/agroup/b75e37ae3736efb70b801f4a576ca72f950c49f8)

### 注册页
![图片](http://bos.nj.bpc.baidu.com/v1/agroup/0e4d3e3f9ed07a6a9a765a3698945c8f50f5335c)